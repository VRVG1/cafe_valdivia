// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'repository_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(clienteRepository)
const clienteRepositoryProvider = ClienteRepositoryProvider._();

final class ClienteRepositoryProvider
    extends
        $FunctionalProvider<
          ClienteRepository,
          ClienteRepository,
          ClienteRepository
        >
    with $Provider<ClienteRepository> {
  const ClienteRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'clienteRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$clienteRepositoryHash();

  @$internal
  @override
  $ProviderElement<ClienteRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ClienteRepository create(Ref ref) {
    return clienteRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ClienteRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ClienteRepository>(value),
    );
  }
}

String _$clienteRepositoryHash() => r'fe48ed6f035c6f85950528307baff5df4bd24b07';

@ProviderFor(proveedorRepository)
const proveedorRepositoryProvider = ProveedorRepositoryProvider._();

final class ProveedorRepositoryProvider
    extends
        $FunctionalProvider<
          ProveedorRepository,
          ProveedorRepository,
          ProveedorRepository
        >
    with $Provider<ProveedorRepository> {
  const ProveedorRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'proveedorRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$proveedorRepositoryHash();

  @$internal
  @override
  $ProviderElement<ProveedorRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ProveedorRepository create(Ref ref) {
    return proveedorRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProveedorRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProveedorRepository>(value),
    );
  }
}

String _$proveedorRepositoryHash() =>
    r'dc85d234e57fc4175d3921084c1c932020c7ae0c';

@ProviderFor(unidadMedidaRepository)
const unidadMedidaRepositoryProvider = UnidadMedidaRepositoryProvider._();

final class UnidadMedidaRepositoryProvider
    extends
        $FunctionalProvider<
          UnidadMedidaRepository,
          UnidadMedidaRepository,
          UnidadMedidaRepository
        >
    with $Provider<UnidadMedidaRepository> {
  const UnidadMedidaRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'unidadMedidaRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$unidadMedidaRepositoryHash();

  @$internal
  @override
  $ProviderElement<UnidadMedidaRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  UnidadMedidaRepository create(Ref ref) {
    return unidadMedidaRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UnidadMedidaRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UnidadMedidaRepository>(value),
    );
  }
}

String _$unidadMedidaRepositoryHash() =>
    r'54aa1e5b92c97a655917375c6b815dec938611d3';

@ProviderFor(insumoRepository)
const insumoRepositoryProvider = InsumoRepositoryProvider._();

final class InsumoRepositoryProvider
    extends
        $FunctionalProvider<
          InsumoRepository,
          InsumoRepository,
          InsumoRepository
        >
    with $Provider<InsumoRepository> {
  const InsumoRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'insumoRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$insumoRepositoryHash();

  @$internal
  @override
  $ProviderElement<InsumoRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  InsumoRepository create(Ref ref) {
    return insumoRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(InsumoRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<InsumoRepository>(value),
    );
  }
}

String _$insumoRepositoryHash() => r'2fd3da406d5c074b624e8ee59fdf0427d6cb2583';

@ProviderFor(compraRepository)
const compraRepositoryProvider = CompraRepositoryProvider._();

final class CompraRepositoryProvider
    extends
        $FunctionalProvider<
          CompraRepository,
          CompraRepository,
          CompraRepository
        >
    with $Provider<CompraRepository> {
  const CompraRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'compraRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$compraRepositoryHash();

  @$internal
  @override
  $ProviderElement<CompraRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CompraRepository create(Ref ref) {
    return compraRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CompraRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CompraRepository>(value),
    );
  }
}

String _$compraRepositoryHash() => r'2e0ebdf6a114b7107ccb5a8fd32636e018f95fc7';
