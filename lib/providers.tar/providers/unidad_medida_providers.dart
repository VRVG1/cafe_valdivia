import 'package:cafe_valdivia/models/unidad_medida.dart';
import 'package:cafe_valdivia/providers/repository_providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'unidad_medida_providers.g.dart';

@Riverpod(keepAlive: false)
Future<UnidadMedida> unidadMedidaDetail(
  AutoDisposeFutureProviderRef ref,
  int id,
) async {
  final repo = ref.watch(unidadMedidaRepositoryProvider);
  return repo.getById(id);
}
