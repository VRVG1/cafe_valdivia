// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'proveedor_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(proveedorDetail)
const proveedorDetailProvider = ProveedorDetailFamily._();

final class ProveedorDetailProvider
    extends
        $FunctionalProvider<
          AsyncValue<Proveedor>,
          Proveedor,
          FutureOr<Proveedor>
        >
    with $FutureModifier<Proveedor>, $FutureProvider<Proveedor> {
  const ProveedorDetailProvider._({
    required ProveedorDetailFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'proveedorDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$proveedorDetailHash();

  @override
  String toString() {
    return r'proveedorDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<Proveedor> $createElement($ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<Proveedor> create(Ref ref) {
    final argument = this.argument as int;
    return proveedorDetail(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is ProveedorDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$proveedorDetailHash() => r'eea3b695a29c0c5325f3711f4d596a08acc386ec';

final class ProveedorDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<Proveedor>, int> {
  const ProveedorDetailFamily._()
    : super(
        retry: null,
        name: r'proveedorDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProveedorDetailProvider call(int id) =>
      ProveedorDetailProvider._(argument: id, from: this);

  @override
  String toString() => r'proveedorDetailProvider';
}
