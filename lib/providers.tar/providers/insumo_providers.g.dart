// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'insumo_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(insumoDetail)
const insumoDetailProvider = InsumoDetailFamily._();

final class InsumoDetailProvider
    extends $FunctionalProvider<AsyncValue<Insumos>, Insumos, FutureOr<Insumos>>
    with $FutureModifier<Insumos>, $FutureProvider<Insumos> {
  const InsumoDetailProvider._({
    required InsumoDetailFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'insumoDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$insumoDetailHash();

  @override
  String toString() {
    return r'insumoDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<Insumos> $createElement($ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<Insumos> create(Ref ref) {
    final argument = this.argument as int;
    return insumoDetail(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is InsumoDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$insumoDetailHash() => r'83340004bcc4441fe912712c7ca76840ec116cdc';

final class InsumoDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<Insumos>, int> {
  const InsumoDetailFamily._()
    : super(
        retry: null,
        name: r'insumoDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  InsumoDetailProvider call(int id) =>
      InsumoDetailProvider._(argument: id, from: this);

  @override
  String toString() => r'insumoDetailProvider';
}
