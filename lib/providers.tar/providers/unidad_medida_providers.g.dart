// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'unidad_medida_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(unidadMedidaDetail)
const unidadMedidaDetailProvider = UnidadMedidaDetailFamily._();

final class UnidadMedidaDetailProvider
    extends
        $FunctionalProvider<
          AsyncValue<UnidadMedida>,
          UnidadMedida,
          FutureOr<UnidadMedida>
        >
    with $FutureModifier<UnidadMedida>, $FutureProvider<UnidadMedida> {
  const UnidadMedidaDetailProvider._({
    required UnidadMedidaDetailFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'unidadMedidaDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$unidadMedidaDetailHash();

  @override
  String toString() {
    return r'unidadMedidaDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<UnidadMedida> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<UnidadMedida> create(Ref ref) {
    final argument = this.argument as int;
    return unidadMedidaDetail(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is UnidadMedidaDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$unidadMedidaDetailHash() =>
    r'57faffdf6eca81cf38e4eb2b4cc389d4f510e10b';

final class UnidadMedidaDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<UnidadMedida>, int> {
  const UnidadMedidaDetailFamily._()
    : super(
        retry: null,
        name: r'unidadMedidaDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  UnidadMedidaDetailProvider call(int id) =>
      UnidadMedidaDetailProvider._(argument: id, from: this);

  @override
  String toString() => r'unidadMedidaDetailProvider';
}
