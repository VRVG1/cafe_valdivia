abstract class BaseModel {
  int? id;
  Map<String, dynamic> toMap();
}
