package com.example.cafe_valdivia

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
